# Teleporty
## Matthias Scherba

This ad-don adds a but-ton that teleports you to the current (or most recent) audible tab. That is, if it's still alive and doing well. Hope you took good care of it.

Icon made by SmashIcons from www.flaticon.com (https://www.flaticon.com/free-icon/portal_2834596)